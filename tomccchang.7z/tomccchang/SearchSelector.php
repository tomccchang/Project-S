  <div id="SearchSelector">
    <!-- keyword -->
    <form class="form-inline" role="form" action="">
    <span>
        <label for="keywordInput">keyword:</label>
        <input class="form-control" id="keywordInput" type="text" style="height: 7mm; width: 100%;">
	</span>
    <!-- keyword -->
	<HR color="green" width="100%" size="10">
    <span>
	</form>
    <!-- date -->
      <label for="Date">Date:</label>
      <input type="datetime-local" id="Date" name="" style="height: 7mm; width: 100%;">
	</span>
	<!-- date -->
	<HR color="green" width="100%" size="10">
	<!-- Area -->
    <form class="form-inline" role="form" action="">
    <span>
        <label for="AreaInput">Area:</label>
        <input class="form-control" id="AreaInput" type="text" style="height: 7mm; width: 100%;">
	</span>
    <!-- Area -->
	<HR color="green" width="100%" size="10">
	<!-- Summit -->
	<button type="button" class="btn btn-info pull-right ">
       <span class="glyphicon glyphicon-search"></span>
    </button>
	<!-- Summit -->
	</form>
  </div>