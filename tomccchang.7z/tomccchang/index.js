function run(demo) {
    //var c = document.getElementById("SearchPanel");
    //var n = document.createElement("p");
    //var message = "Hello, JavaScript!";
    //n.appendChild(document.createTextNode(message));
    //c.appendChild(n);
    //demo.style.visibility = "hidden";
}

function SecnarioBtn() {

    SearchPanel.style.visibility = "hidden";
}

function SearchBtn() {
    SearchPanel.style.visibility = "visible";
}

