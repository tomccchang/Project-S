<div class="btn-group pull-right">
  <a type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown">
廠商資料
<span class="caret"></span></a>
  <ul class="dropdown-menu" role="menu">
    <li><a href="regi_supplier.php" id="ablock_i">基本資料</a></li>
    <li><a href="Contact.php" id="ablock_i">聯絡資料</a></li>
    <li><a href="cv.php" id="ablock_i">個人介紹</a></li>
    <li><a href="Project.php" id="ablock_i">作品與圖片</a></li>
    <li><a href="ChargeList.php" id="ablock_i">收費項目</a></li>
    <li><a href="Referral.php" id="ablock_i">介紹獎勵</a></li>
  </ul>
</div>