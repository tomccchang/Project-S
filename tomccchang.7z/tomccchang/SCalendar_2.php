<? header("Content-Type:text/html; charset=utf-8");
session_start();

?>
  <!DOCTYPE html>
  <html>

  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="styles.css" rel="stylesheet">
    <!--<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">-->

    <meta charset='utf-8' />
    <link href='fullcalendar3/fullcalendar.css' rel='stylesheet' />
    <link href='fullcalendar3/fullcalendar.print.css' rel='stylesheet' media='print' />
    <script src='fullcalendar3/lib/moment.min.js'></script>
    <script src='fullcalendar3/lib/jquery.min.js'></script>
    <script src='fullcalendar3/fullcalendar.min.js'></script>
    <script>
      var SelStartDate;
      var SelEndDate;
      var calendar;
      var CurrentSelDate;

      $(document).ready(function() {
        var date = new Date();
        var d = date.getDate();
        var m = date.getMonth();
        var y = date.getFullYear();
        calendar = $('#calendar').fullCalendar({
          header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
          },

          dayClick: function(date, jsEvent, view) {
            //alert('Clicked on: ' + date.format());
            //alert('Coordinates: ' + jsEvent.pageX + ',' + jsEvent.pageY);
            //alert('Current view: ' + view.name);
            //get date 
            var SelDate = date.format();
            // set default input value
            //$("#SCalendar_TimeStart").val(SelDate + 'T08:00:00');
            //$("#SCalendar_TimeEnd").val(SelDate + 'T17:00:00');
          
            //remove previous highlight
            //$(".fc-state-highlight").removeClass("fc-state-highlight");
            // hightlingt select day
            //$(this).addClass("fc-state-highlight")
  
           calendar.fullCalendar('gotoDate', SelDate);
           calendar.fullCalendar( 'changeView', 'agendaDay');
          },


          navLinks: true, // can click day/week names to navigate views
          editable: true,
          eventLimit: true, // allow "more" link when too many events

          events: "Cal_events.php",
          selectable: true,
          selectHelper: true,
          select: function(start, end, allDay) {// select a peroid
            // get date
            var start = moment(start).format('YYYY-MM-DDTHH:mm:ssZ');
            var end = moment(end).format('YYYY-MM-DDTHH:mm:ssZ');
            // store date
            SelStartDate = start;
            SelEndDate = end;
            
            // Set default input
            var SelStart= moment(start).format('YYYY-MM-DD');
            //var SelEnd= moment(end).format('YYYY-MM-DD');
            var SelEnd = moment(end).subtract(1,'days').format('YYYY-MM-DD'); 
            $("#SCalendar_TimeStart").val(SelStart + 'T08:00:00');
            $("#SCalendar_TimeEnd").val(SelEnd + 'T17:00:00');

            //remove previous highlight
            $(".fc-state-highlight").removeClass("fc-state-highlight");
            // hightlingt select day
            //$(this).addClass("fc-state-highlight");
            //$("td[data-date=" + SelStart + "]").addClass("fc-state-highlight");
            var duriation = moment(SelEnd).diff(SelStart, 'days');
            var HLDate;
            for(var i = 0; i<= duriation; i++){
              HLDate = moment(start).add(i,'days').format('YYYY-MM-DD'); 
              $("td[data-date=" + HLDate + "]").addClass("fc-state-highlight");
            }

/*            
            var title = prompt('Event Title:');
            if (title) {
              var start = moment(start).format('YYYY-MM-DDTHH:mm:ssZ');
              var end = moment(end).format('YYYY-MM-DDTHH:mm:ssZ');
              //for test
              SelStartDate = start;
              SelEndDate = end;

              $.ajax({
                url: 'Cal_add_events.php',
                data: 'title=' + title + '&start=' + start + '&end=' + end,
                type: "POST",
                success: function(json) {
                  alert('OK');
                }
              });
              calendar.fullCalendar('renderEvent', {
                  title: title,
                  start: start,
                  end: end,
                  allDay: allDay
                },
                true // make the event "stick"
              );

            }//if (title)
*/            
            calendar.fullCalendar('unselect');
          }//select: function(start, end, allDay)
        }); // end for $('#calendar').fullCalendar({

      }); // end for $(document).ready(function() {

      function CalendarSet() {
        //var start = SelStartDate;
        //var end = SelEndDate;
        var start = $("#SCalendar_TimeStart").val();
        var end = $("#SCalendar_TimeEnd").val();
       // get value
       var title = $("#SCalendar_title").val();
       // alert($("#SCalendar_title").val());//fir debug
       
       // add new event to calendar
        $.ajax({ 
          url: 'Cal_add_events.php',
          data: 'title=' + title + '&start=' + start + '&end=' + end,
          type: "POST",
          success: function(json) {
            alert('OK');
          }
        });
        
        // update calendar in client
        calendar.fullCalendar('renderEvent', {
            title: title,
            start: start,
            end: end,
            //allDay: 'false'
          },
          false // make the event "stick"
        );

      }// CalendarSet()
    </script>
    <style>
      body {
        margin: 40px 10px;
        padding: 0;
        font-family: "Lucida Grande", Helvetica, Arial, Verdana, sans-serif;
        font-size: 14px;
      }
      
      #calendar {
        max-width: 900px;
        margin: 0 auto;
      }
      /* for hightlight date*/
      .fc-state-highlight {background:red;}
    </style>
  </head>

  <body>
    <div id="menu_all"></div>
    <div class="col-sm-12 hidden visible-xs">
      <span></span>
    </div>
    <div id='calendar' style="margin-top:8%;"></div>

    <div id="SCalendarCotroller" class="row">
      <?php include("SCalendar/SCalendarCotroller.php");?>
    </div>


    <script>
      $("#menu_all").load("menu.php #menu_all");
    </script>
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>

  </body>

  </html>