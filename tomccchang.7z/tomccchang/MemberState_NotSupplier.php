<a type="button" class="btn btn-info pull-right" href="../regi_supplier.php">
  <span></span>成為廠商
</a>