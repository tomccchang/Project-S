<style>
  #SCalendarCotrollerContent {
    position: fixed;
    z-index: 20;
    bottom: 0;
    width: 100%;
    margin-right: 0;
    margin-left: 0;
    padding-top: 10px;
    padding-bottom: 10px;
    background: rgba(32, 32, 32, 0.4);
  }
</style>


<div id="SCalendarCotrollerContent" class="row">
  <div class="row">

    <div class="hidden-xs col-sm-1 col-md-1 col-lg-1"></div>
    <!-- keyword -->
    <div class="col-xs-10 col-xs-offset-1 col-sm-4 col-sm-offset-0 col-md-3 col-md-offset-0 col-lg-3 col-lg-offset-0">
      <div id="">
        <input class="form-control" id="SCalendar_title" name="KeyWord" type="text" placeholder="Event title" value="">
      </div>
    </div>
    <!-- keyword -->


    <!-- date -->
    <div class="col-xs-10 col-xs-offset-1 col-sm-3 col-sm-offset-0 col-md-3 col-md-offset-0 col-lg-3 col-lg-offset-0">
      <div id="">
        <!--<label for="Date">Date:</label> -->
        <input type="datetime-local" id="SCalendar_TimeStart" name="" step="1800" value="">
      </div>
    </div>
    <!-- date -->

    <!-- Area -->
    <div class="col-xs-10 col-xs-offset-1 col-sm-4 col-sm-offset-0 col-md-3 col-md-offset-0 col-lg-3 col-lg-offset-0">
      <div id="">
        <input type="datetime-local" id="SCalendar_TimeEnd" name="" step="1800" value="">
      </div>
    </div>
    <!-- Area -->


    <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">

      <div id="SearchWzard_btn_groop" class="pull-right">
        <!-- Summit -->
        <button id="SearchWzard_btn" type="button" class="btn btn-info"  onclick="CalendarSet()">
          <span class="glyphicon glyphicon-ok"></span>
        </button>
        <!-- Summit -->

        <!-- close -->
        <button id="SearchWzard_btn" type="button" class="btn btn-info" onclick="CalendarSet()">
          <span class="glyphicon glyphicon-remove"></span>
        </button>
        <!-- close -->
      </div>

    </div>

  </div>

</div>