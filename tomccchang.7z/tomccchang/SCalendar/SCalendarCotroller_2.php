<style>
  #SCalendarCotrollerContent {
    position: fixed;
    z-index: 20;
    top: 20mm;
    width: 100%;
    margin-right: 0;
    margin-left: 0;
    padding-top: 10px;
    padding-bottom: 10px;
    background: rgba(32, 32, 32, 0.4);
  }
</style>


<div id="SCalendarCotrollerContent" class="row">
  <div class="row">

    <div class=""></div>
    <!-- keyword -->
    <div class="">
      <div id="">
        <input class="form-control" id="SCalendar_title" name="KeyWord" type="text" placeholder="Event title" value="">
      </div>
    </div>
    <!-- keyword -->


    <!-- date -->
    <div class="">
      <div id="">
        <!--<label for="Date">Date:</label> -->
        <input type="datetime-local" id="SCalendar_TimeStart" name="" step="1800" value="">
      </div>
    </div>
    <!-- date -->

    <!-- Area -->
    <div class="">
      <div id="">
        <input type="datetime-local" id="SCalendar_TimeEnd" name="" step="1800" value="">
      </div>
    </div>
    <!-- Area -->


    <div class="">

      <div id="SearchWzard_btn_groop" class="pull-right">
        <!-- Summit -->
        <button id="SearchWzard_btn" type="button" class="btn btn-info"  onclick="CalendarSet()">
          <span class="glyphicon glyphicon-ok"></span>
        </button>
        <!-- Summit -->

        <!-- close -->
        <button id="SearchWzard_btn" type="button" class="btn btn-info" onclick="CalendarSet()">
          <span class="glyphicon glyphicon-remove"></span>
        </button>
        <!-- close -->
      </div>

    </div>

  </div>

</div>