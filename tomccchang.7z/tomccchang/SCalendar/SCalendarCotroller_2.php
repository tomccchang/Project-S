<style>
  #SCalendarCotrollerContent {
    position: fixed;
    z-index: 20;
    top: 40mm;
    padding-top: 40px;
    padding-bottom: 40px;
    padding-left: 10px;
    padding-right: 10px;
    background: rgba(217, 250, 214, 0.25);
    border-radius: 25px;
  }
  
  #SCalendarCotrollerContent input {
    margin-top: 20px;
  }
  
  #SCalendar_Content {
    height: 120px;
  }
  
  #SCalendar_Remark {
    height: 120px;
  }

  #SearchWzard_btn_groop{
    margin-top: 20px;
  }
</style>

<div class="row">

  <div id="SCalendarCotrollerContent" class="col-xs-4 col-xs-offset-4 col-sm-4 col-sm-offset-4 col-md-4 col-md-offset-4 col-lg-4 col-lg-offset-4">

    <!-- Title -->
    <div id="">
      <input class="form-control" id="SCalendar_title" name="KeyWord" type="text" placeholder="Event title" value="">
    </div>
    <!-- Title -->


    <!--Time start-->
    <div id="">
      <!--<label for="Date">Date:</label> -->
      <input type="datetime-local" id="SCalendar_TimeStart" name="" step="1800" value="">
    </div>
    <!-- Time start -->

    <!-- Time End -->
    <div id="">
      <input type="datetime-local" id="SCalendar_TimeEnd" name="" step="1800" value="">
    </div>
    <!-- Time End -->

    <!-- Content -->
    <div id="">
      <input class="form-control" id="SCalendar_Content" name="KeyWord" type="text" placeholder="Event title" value="">
    </div>
    <!-- Content -->

    <!-- Remark -->
    <div id="">
      <input class="form-control" id="SCalendar_Remark" name="KeyWord" type="text" placeholder="Event title" value="">
    </div>
    <!-- Remark -->

    <div id="SearchWzard_btn_groop" class="pull-right">
      <!-- Summit -->
      <button id="SearchWzard_btn" type="button" class="btn btn-info" onclick="CalendarSet()">
        <span class="glyphicon glyphicon-ok"></span>
      </button>
      <!-- Summit -->

      <!-- close -->
      <button id="SearchWzard_btn" type="button" class="btn btn-info" onclick="CalendarSet()">
        <span class="glyphicon glyphicon-remove"></span>
      </button>
      <!-- close -->
    </div>



  </div>
  <!--id="SCalendarCotrollerContent"-->

</div>