<?
session_start();
date_default_timezone_set("Asia/Taipei");
if(!isset($_SESSION['or'])||($_SESSION['or']=="t"))
{
    $_SESSION['KeyWord']="";
}
?>



  <div class="row">
    <form action="../Search.php">
      <div class="row">

        <div class="hidden-xs col-sm-1 col-md-1 col-lg-1"></div>
        <!-- keyword -->
        <div class="col-xs-10 col-xs-offset-1 col-sm-4 col-sm-offset-0 col-md-3 col-md-offset-0 col-lg-3 col-lg-offset-0">
          <div id="Calender">
            <input class="form-control" id="KeyWord" name="KeyWord" type="text" placeholder="想辦什麼活動?想找什麼人?需要什麼商品?" value="<? echo $_SESSION['KeyWord']; ?>">
          </div>
        </div>
        <!-- keyword -->


        <!-- date -->
        <div class="col-xs-10 col-xs-offset-1 col-sm-3 col-sm-offset-0 col-md-3 col-md-offset-0 col-lg-3 col-lg-offset-0">
          <div id="Calender">
            <!--<label for="Date">Date:</label> -->
            <input type="datetime-local" id="RTime" name="RTime" step="1800" value="<? echo $_SESSION['RTime']; ?>">
          </div>
        </div>
        <!-- date -->

        <!-- Area -->
        <div class="col-xs-10 col-xs-offset-1 col-sm-4 col-sm-offset-0 col-md-3 col-md-offset-0 col-lg-3 col-lg-offset-0">
          <div id="Calender">
            <span><input class="form-control" id="Area" name="Area" type="text"  placeholder="地區?" value="<? echo $_SESSION['Area']; ?>"></span>
          </div>
        </div>
        <!-- Area -->


        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2">

          <div id="SearchWzard_btn_groop" class="pull-right">
            <!-- Summit -->
            <button id="SearchWzard_btn" type="submit" class="btn btn-info">
              <span class="glyphicon glyphicon-ok"></span>
            </button>
            <!-- Summit -->

            <!-- close -->
            <button id="SearchWzard_btn" type="button" class="btn btn-info" onclick="CloseSearchWizard();">
              <span class="glyphicon glyphicon-remove"></span>
            </button>
            <!-- close -->
          </div>

        </div>
       
      </div>
    </form>
  </div>