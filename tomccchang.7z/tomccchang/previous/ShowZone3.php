
<?php
$sql=" SELECT * FROM V_IndexSP Where Active='Y' and Kind='YearEnd'";
global $ImgName;
mysqli_query($link,'SET NAMES utf8');
if($result=mysqli_query($link,$sql)){
    $n=0;
    while ($row=mysqli_fetch_assoc($result)){
        
        $sd[$n] = $row["UID"];
        $Pic[$n] = $row["Pic"];
        $Kind[$n] = $row["Kind"];
        $ISPR[$n] = $row["ISPR"];
        $Note[$n] = $row["Note"];
        $Start[$n] = $row["Start"];
        $End[$n] = $row["End"];
        $Active[$n] = $row["Active"];
        $Alt[$n] = $row["Alt"];
        $S_NAME[$n] = $row["S_NAME"];
        $ActionCategory[$n] = $row["ActionCategory"];
        $KeyWord[$n] = $row["KeyWord"];
        $CV[$n] = $row["CV"];
        $Service[$n] = $row["Service"];
        $AVG[$n] = $row["AVG"];
        $ImgName[$n]="../SupplierPic/".$sd[$n]."/".$row["Pic"];
        $CV[$n] = (mb_substr( $row["CV"],0,57,"utf-8"));
        $CV[$n] .="...";

        $n++;
    } // end of while ($row=mysqli_fetch_assoc($result)){
}// end of if($result=mysqli_query($link,$sql)){
mysqli_free_result($result);
?>


</div>
<!--test-->
  <div class="row">
    <!--Left-->
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
		  <div class="row">
		   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6" style="padding:5px;">
		     <?php
               for($i=0; $i<4; $i++){
                 echo "<div><img  src=$ImgName[$i] alt=\"Chania\" style=\"width:100%; height:auto\"></div>";
	           }
              ?> 
		   </div>
		   
		   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6" style="padding:5px;">
		     <?php
               for($i=3; $i>=1; $i--){
                 echo "<div><img  src=$ImgName[$i] alt=\"Chania\" style=\"width:100%; height:auto\"></div>";
	          }
              ?> 
		  </div>
		</div><!--<div class="row">-->  
     </div><!--<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">-->
     <!--Left-->

    <!--Right-->
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
		  <div class="row">
		   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6" style="padding:5px;">
		     <?php
               for($i=0; $i<4; $i++){
                 echo "<div><img  src=$ImgName[$i] alt=\"Chania\" style=\"width:100%; height:auto\"></div>";
	           }
              ?> 
		   </div>
		   
		   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6" style="padding:5px;">
		     <?php
               for($i=3; $i>=1; $i--){
                 echo "<div><img  src=$ImgName[$i] alt=\"Chania\" style=\"width:100%; height:auto\"></div>";
	          }
              ?> 
		  </div>
		</div><!--<div class="row">-->  
     </div><!--<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">-->
     <!--Right-->

  </div> <!--<div class="row">-->

<!--debug -->
<div id="debug" class="row">
<?php
$size = getimagesize($ImgName[1]);
echo $ImgName[1];
echo $size[0];
?>
</div>
<!--debug -->
