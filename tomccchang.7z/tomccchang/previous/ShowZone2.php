<div class="row">
  <h2 id="redH3" style="text-align:center;"><strong>尾牙驚選活動廠商</strong></h2>
</div>

<?php
$sql=" SELECT * FROM V_IndexSP Where Active='Y' and Kind='YearEnd'";
global $ImgName;
mysqli_query($link,'SET NAMES utf8');
if($result=mysqli_query($link,$sql)){
    $n=0;
    while ($row=mysqli_fetch_assoc($result)){
        
        $sd[$n] = $row["UID"];
        $Pic[$n] = $row["Pic"];
        $Kind[$n] = $row["Kind"];
        $ISPR[$n] = $row["ISPR"];
        $Note[$n] = $row["Note"];
        $Start[$n] = $row["Start"];
        $End[$n] = $row["End"];
        $Active[$n] = $row["Active"];
        $Alt[$n] = $row["Alt"];
        $S_NAME[$n] = $row["S_NAME"];
        $ActionCategory[$n] = $row["ActionCategory"];
        $KeyWord[$n] = $row["KeyWord"];
        $CV[$n] = $row["CV"];
        $Service[$n] = $row["Service"];
        $AVG[$n] = $row["AVG"];
        $ImgName[$n]="../SupplierPic/".$sd[$n]."/".$row["Pic"];
        $CV[$n] = (mb_substr( $row["CV"],0,57,"utf-8"));
        $CV[$n] .="...";
       
        //echo $ImgName[n];//test
        //$test[n] = n;
        $n++;
    } // end of while ($row=mysqli_fetch_assoc($result)){
}// end of if($result=mysqli_query($link,$sql)){
mysqli_free_result($result);
//   mysqli_free_result($result);
?>
<!--尾牙驚選開始 -->
<!--debug -->

<div id="debug" class="row">
<?php
//$sql=" SELECT * FROM V_IndexSP Where Active='Y' and Kind='YearEnd'";
//echo $sql;
  //for ($i = 1; $i < 3; $i++) {
   // echo $i . "\n";
    //echo $ImgName[i];
 // }
 $test = "<div><img  src=\"w1.png\" alt=\"Chania\" style=\"width:100%; height:auto\"></div>";
 echo "<div><img  src=\"$ImgName[0]\" alt=\"Chania\" style=\"width:100%; height:auto\"></div>";
 //echo $sql;
 //echo $test[1];
 //echo $n;
 //echo $ImgName[0];
?>
</div>
<!--debug -->
