<div id="test" class="row">
  <?php
class ImageRectArray{
    public $ImgHeight_N;
    public $ImgHeight_N_ratio;
    public $ImgNameList;
    

    function group($ImgName){
        $n = 8;
        $t = 0;
        $ImgHeight_N[0] = 0;
        $ImgHeight_N[1] = 0;
        $ImgHeight_N[2] = 0;
        $ImgHeight_N[3] = 0;
        for($i=0;$i<$n;$i++){
            $size = getimagesize($ImgName[$i]);
            $width = $size[0];
            $Height = $size[1];
            $s = $i%4;
            $ImgHeight_N[$s] += $Height/$width;
            echo "i=".$i."  s=".$s."  ImgHeight_N=".$ImgHeight_N[$s]."\n";
            
            $ImgNameList[$s][$t] = $ImgName[$i];
            echo "t=".$t."  ImgNameList=".$ImgNameList[$s][$t]."\n";
            if($s == 3)
            {$t++;}
        }
        $ImgHeight_N_min = min($ImgHeight_N);
        echo "ImgHeight_N_min=".$ImgHeight_N_min."\n";
        
        for($i=0;$i<4;$i++){
            $ImgHeight_N_ratio[$i] = $ImgHeight_N_min/$ImgHeight_N[$i];
            $ImgHeight_N_ratio[$i] = $ImgHeight_N_ratio[$i]*100;
            echo "ImgHeight_N_ratio=".$ImgHeight_N_ratio[$i]."\n";
        }
        $ImgHeight_N_sum = array_sum($ImgHeight_N_ratio);
        echo "ImgHeight_N_sum=".$ImgHeight_N_sum."\n";
        for($i=0;$i<4;$i++){
            $ImgHeight_N_ratio[$i] = $ImgHeight_N_ratio[$i] / $ImgHeight_N_sum * 10000;
            $ImgHeight_N_ratio[$i] = round($ImgHeight_N_ratio[$i]);
            $ImgHeight_N_ratio[$i] = $ImgHeight_N_ratio[$i]/100;
            echo "ImgHeight_N_ratio=".$ImgHeight_N_ratio[$i]."\n";
        }
        
        $this->ImgHeight_N_ratio = $ImgHeight_N_ratio;
        $this->ImgHeight_N = $ImgHeight_N;
        $this->ImgNameList = $ImgNameList;
    }// group()
    
}//class ImageRectArray





?>