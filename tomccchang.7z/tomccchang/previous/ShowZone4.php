
<?php
$sql=" SELECT * FROM V_IndexSP Where Active='Y' and Kind='selected'";
global $ImgName;
mysqli_query($link,'SET NAMES utf8');
if($result=mysqli_query($link,$sql)){
    $n=0;
    while ($row=mysqli_fetch_assoc($result)){
        
        $sd[$n] = $row["UID"];
        $Pic[$n] = $row["Pic"];
        $Kind[$n] = $row["Kind"];
        $ISPR[$n] = $row["ISPR"];
        $Note[$n] = $row["Note"];
        $Start[$n] = $row["Start"];
        $End[$n] = $row["End"];
        $Active[$n] = $row["Active"];
        $Alt[$n] = $row["Alt"];
        $S_NAME[$n] = $row["S_NAME"];
        $ActionCategory[$n] = $row["ActionCategory"];
        $KeyWord[$n] = $row["KeyWord"];
        $CV[$n] = $row["CV"];
        $Service[$n] = $row["Service"];
        $AVG[$n] = $row["AVG"];
        $ImgName[$n]="../SupplierPic/".$sd[$n]."/".$row["Pic"];
        $CV[$n] = (mb_substr( $row["CV"],0,57,"utf-8"));
        $CV[$n] .="...";

        $n++;
    } // end of while ($row=mysqli_fetch_assoc($result)){
}// end of if($result=mysqli_query($link,$sql)){
mysqli_free_result($result);
?>
<div id="test" class="row">
<?php

    $t = 0;
    $ImgHeight_N[0] = 0;
    $ImgHeight_N[1] = 0;
    $ImgHeight_N[2] = 0;
    $ImgHeight_N[3] = 0;
    for($i=0;$i<$n;$i++){
      $size = getimagesize($ImgName[$i]);
      $width = $size[0];
      $Height = $size[1];
      $s = $i%4;
      $ImgHeight_N[$s] += $Height/$width;
      echo "i=".$i."  s=".$s."  ImgHeight_N=".$ImgHeight_N[$s]."\n";

      $ImgNameList[$s][$t] = $ImgName[$i];
      echo "t=".$t."  ImgNameList=".$ImgNameList[$s][$t]."\n";
      if($s == 3)
      {$t++;}
    }
      $ImgHeight_N_min = min($ImgHeight_N);
      echo "ImgHeight_N_min=".$ImgHeight_N_min."\n";

   for($i=0;$i<4;$i++){
      $ImgHeight_N_ratio[$i] = $ImgHeight_N_min/$ImgHeight_N[$i];
      $ImgHeight_N_ratio[$i] = $ImgHeight_N_ratio[$i]*100;
      echo "ImgHeight_N_ratio=".$ImgHeight_N_ratio[$i]."\n";
    }   
      
?>
</div>
<!--test-->
  <div class="row">
    <!--Left-->
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
		  <div class="row">
		   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6" style="padding:0px; text-align:center;">
		     <?php
               //for($i=0; $i<4; $i++){
                 //echo "<div><img  src=$ImgName[$i] alt=\"Chania\" style=\"width:100%; height:auto\"></div>";
	           //}
             for($i=0; $i<2; $i++){
                 $name = $ImgNameList[0][$i];
                 //echo $ImgNameList[0][$i];
                 echo "<div><img  src=$name alt=\"Chania\" style=\"width:86%; height:auto\"></div>";
	           }
              ?> 
		   </div>
		   
		   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6" style="padding:0px; text-align:center;">
		     <?php
              // for($i=3; $i>=1; $i--){
                // echo "<div><img  src=$ImgName[$i] alt=\"Chania\" style=\"width:100%; height:auto\"></div>";
	          //}
             for($i=0; $i<2; $i++){
                 $name = $ImgNameList[1][$i];
                 //echo $ImgNameList[1][$i];
                 echo "<div><img  src=$name alt=\"Chania\" style=\"width:100%; height:auto\"></div>";
	           }
              ?> 
		  </div>
		</div><!--<div class="row">-->  
     </div><!--<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">-->
     <!--Left-->

    <!--Right-->
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
		  <div class="row">
		   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6" style="padding:0px; text-align:center;">
		     <?php
             for($i=0; $i<2; $i++){
                 $name = $ImgNameList[2][$i];
                 //echo $ImgNameList[2][$i];
                 echo "<div><img  src=$name alt=\"Chania\" style=\"width:85%; height:auto\"></div>";
	           }
              ?> 
		   </div>
		   
		   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6" style="padding:0px; text-align:center;">
		     <?php
             for($i=0; $i<2; $i++){
                 $name = $ImgNameList[3][$i];
                 //echo $ImgNameList[3][$i];
                 echo "<div><img  src=$name alt=\"Chania\" style=\"width:98%; height:auto\"></div>";
	           }
              ?> 
		  </div>
		</div><!--<div class="row">-->  
     </div><!--<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">-->
     <!--Right-->

  </div> <!--<div class="row">-->

<!--debug -->
<div id="debug" class="row">
<?php
//$size = getimagesize($ImgName[1]);
//echo $ImgName[1];
//echo $size[0];
?>
</div>
<!--debug -->
