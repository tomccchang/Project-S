<!--尾牙驚選開始 -->
<div class="row">
  <h2 id="redH3" style="text-align:center;"><strong>尾牙驚選活動廠商</strong></h2>
</div>
<div class="row">
  <?

$sql=" SELECT * FROM V_IndexSP Where Active='Y' and Kind='YearEnd'";
mysqli_query($link,'SET NAMES utf8');
if($result=mysqli_query($link,$sql)){
    $n=1;
    while ($row=mysqli_fetch_assoc($result)){
        
        $sd=$row["UID"];
        $Pic=$row["Pic"];
        $Kind=$row["Kind"];
        $ISPR=$row["ISPR"];
        $Note=$row["Note"];
        $Start=$row["Start"];
        $End=$row["End"];
        $Active=$row["Active"];
        $Alt=$row["Alt"];
        $S_NAME=$row["S_NAME"];
        $ActionCategory=$row["ActionCategory"];
        $KeyWord=$row["KeyWord"];
        $CV=$row["CV"];
        $Service=$row["Service"];
        $AVG=$row["AVG"];
        $ImgName="../SupplierPic/".$sd."/".$row["Pic"];
        $CV = (mb_substr( $row["CV"],0,57,"utf-8"));
        // $Note= (mb_substr( $row["Note"],0,30,"utf-8"));
        $CV .="...";
        //echo "*******".$n; 這裡到底是要mod多少，明天要思考一下
        if(($n%5)=='0' && $n!='5'){
            //每4個要一個row
            ?>
    <div class="row">
      <?
        }
        
        ?>
        <div class="col-sm-3 "> <a id="ablock_i" target="_blank" href="SearchR.php?sd=<?echo $sd;?>&Avg=<?echo $AVG;?>" style="text-align:center;"> <img class="img-responsive " alumb="true" src="<? echo $ImgName ;?>" alt="<?echo "線上預約".$Alt;?>"><p id="p16" style="color:red;"><?echo $Note;?></p><p id="p16"> <?echo $S_NAME."(".$AVG.")"; ?></p><p id="p14"><?echo $Service; ?></p><p id="p14" style="text-align:left;"><?echo $CV;?></p></a>          </div>
        <?
        // if( ($n % 4)==0){
        if(($n%5)=='0'){
            //每4個要一個row
            ?>
    </div>
    <!-- <div class="row"> -->
    <?
            
        }
        $n=$n+1;
    } // end of while ($row=mysqli_fetch_assoc($result)){
}// end of if($result=mysqli_query($link,$sql)){
mysqli_free_result($result);
//   mysqli_free_result($result);
?>
</div>
<!-- <div class="row "> -->
<!--尾牙驚選開始 -->