<? session_start(); ?>
<!doctype html>
<html lang="zh_TW">

<head>
<meta charset="utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="Lulu lu">
<title>Synparta</title>
    <!-- Bootstrap core CSS -->
 

<body  >
<!--Main Menu -->
<!-- wrapper
    ================================================== -->
<div class="navbar-wrapper"  id="menu_all" style="margin-top:0px;"  >


      <div class="container"  style=" position: relative; width:100% !important;padding-right:0px; padding-left:0px;">

        <nav class="navbar navbar-inverse navbar-fixed-bottom" style="border-color:transparent;" >
          <div class="container" >
            <div class="navbar-header" >
            <div class="row">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only" >Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
                  <div >
                  <a  href="index.php">   <img src="images/synparta_word2_s.png"> </a>

                  </div>  <!-- <div class="hidden-xs"> -->
         
             </div>  <!-- <div class="row"> -->
            </div>
            <div id="navbar" class="navbar-collapse collapse"  style="text-align:center;" >
              
        <!--login start -->
      
    <ul class="navbar-nav  navbar-right" style="float:right; list-style-type:none;"   >   
       <?php if ($_SESSION['FBID'] && ($_SESSION['USER_ACTIVE']=='Y') ): ?>      <!--  After user login  -->
        

      
        <li style="float:!important;" style="float:right; padding-right:6px;padding-left:6px;" ><a href="index.php"  id="ablock_i" style="padding-right:6px;padding-left:6px" ><img height="20px"  width="20px" class="img-circle"  src="https://graph.facebook.com/<?php echo $_SESSION['FBID']; ?>/picture"><?php echo $_SESSION['FULLNAME']; ?></a> </li>
        <!-- <li   style="float:!important;" style="float:right; color:#F03; "><a href="#" id="ablock_i"><span class="glyphicon glyphicon-heart"></span> 追蹤清單</a></li>  -->

    <li  class="dropdown" >
  <a class="dropdown-toggle" text-align="center" data-toggle="dropdown" href="#" id="ablock_i"  style="background-color:inherit !important; padding-right:6px;padding-left:6px; ">&nbsp;&nbsp;訂單紀錄<span class="caret"></span></a>
          <ul class="dropdown-menu" id="ablock_ul">
            <li ><a href="TradeMatch.php" id="ablock_i" >待回覆訂單</a></li>
            <li ><a href="TradeCm.php?H=N" id="ablock_i">未到期訂單</a></li>
            <li ><a href="TradeCm.php?H=Y" id="ablock_i">已過期訂單</a></li>
            <li ><a href="Ranking.php" id="ablock_i">評價紀錄</a></li>
           </ul> 
</li>

    <li   style="float:!important;" style="float:right; color:#F03; padding-right:6px !important;padding-left:6px !important;"><a href="Calendar.php"  id="ablock_i"  style="padding-right:6px !important;padding-left:6px !important;">&nbsp;&nbsp;行事曆</a></li>
    <li   style="float:!important;" style="float:right; color:#F03; padding-right:6px !important;padding-left:6px !important; "><a href="register.php" id="ablock_i"  style="padding-right:6px !important;padding-left:6px !important;" <? if($_SESSION['SUPPLIER']==null){ ?> title="請先寫會員資料歐!"<? }?>>&nbsp;&nbsp;會員資料</a></li>
 
 <? //判斷是否為廠商，如果是的話，出現功能列
 //echo "*".$_SESSION['SUPPLIER'];
 if ($_SESSION['SUPPLIER']=="Y" ){
  
  ?>

  <li  class="dropdown" >
  <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="ablock_i"  style="background-color:inherit !important; padding-right:6px;padding-left:6px;">&nbsp;&nbsp;廠商資料<span class="caret"></span></a>
          <ul id="ablock_ul" class="dropdown-menu" text-align="center">
            <li><a href="regi_supplier.php" id="ablock_i" >基本資料</a></li>
                 <li><a href="Contact.php" id="ablock_i">聯絡資料</a></li> 
            <li><a href="cv.php" id="ablock_i">個人介紹</a></li>
       
            <li><a href="Project.php" id="ablock_i">作品與圖片</a></li> 
            <li><a href="ChargeList.php" id="ablock_i">收費項目</a></li> 
            <li><a href="Referral.php" id="ablock_i">介紹獎勵</a></li> 
           </ul> 
 
 <?  } else{ //if ( (trim($_SESSION['SUPPLIER'])!=null) || ($_SESSION['SUPPLIER']=="N"))  {  

   ?>
 
 
  
   <li   style="float:!important;" style="float:right; color:#F03; "><a href="regi_supplier.php" id="ablock_i" style="padding-right:6px;padding-left:6px;">&nbsp;&nbsp;成為廠商</a></li>
  
  <? } // end if for suppliser menu ?>
 
        <li  style="float:!important;"  style="flost:right;color:#F03;" ><a href="logout.php" id="ablock_i" style="padding-right:6px;padding-left:6px;">&nbsp;&nbsp;登出</a></li>         
        
       
            <?php else: ?>     <!-- Before login --> 
       
                  
        <li style="float:right;"  >
              <a href="loginwithfb/fbconfig.php" id="ablock_i">登入(支援FB登入)</a></div>
        </li>
            
            <?php endif ?>
    </ul>
        <!-- login end-->
        
                
             
             
                
             
               
               
             
           
            </div>
          </div>
        </nav>

      </div>
 <script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>


<!-- end wrapper -->



   
   

     
   
</body>
</html>