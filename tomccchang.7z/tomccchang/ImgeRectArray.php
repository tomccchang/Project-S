
  <?php
class ImageRectArray{
    public $ImgHeight_N;
    public $ImgHeight_N_ratio;// width Ratio
    public $ImgWidthRatio;// width Ratio
    public $ImgNameList;// path list
    public $GroupIndex; // group list

    function group($ImgName, $ImageNum, $GroupNum){
        //$ImageNum = 8;
        //$GroupNum = 4;
        
        // Initial
        for($i=0;$i<$GroupNum;$i++){
            $ImgHeight_N[$i] = 0;
        }
        
        // get H/W ratio & group list
        $t = 0;
        for($i=0;$i<$ImageNum;$i++){ 
            $size = getimagesize($ImgName[$i]);
            //$width = $size[0];
            //$Height = $size[1];
            $s = $i % $GroupNum;
            $ImgHeight_N[$s] += $size[1] / $size[0];//$Height/$width;
            //echo "i=".$i."  s=".$s."  ImgHeight_N=".$ImgHeight_N[$s]."\n";
            $ImgNameList[$s][$t] = $ImgName[$i];
            //echo "t=".$t."  ImgNameList=".$ImgNameList[$s][$t]."\n";
            $GroupIndex[$s][$t] = $i;
            
            if($s == $GroupNum - 1){$t++;}// sift index of group
        }
        
        // get ratio to compensat the length of groups
        $ImgHeight_N_min = min($ImgHeight_N);
        //echo "ImgHeight_N_min=".$ImgHeight_N_min."\n";
        for($i=0;$i<$GroupNum;$i++){
            $ImgHeight_N_ratio[$i] = $ImgHeight_N_min / $ImgHeight_N[$i];
            //echo "ImgHeight_N_ratio=".$ImgHeight_N_ratio[$i]."\n";
        }
        
        // redistribute the width of groups
        $ImgHeight_N_sum = array_sum($ImgHeight_N_ratio);
        //echo "ImgHeight_N_sum=".$ImgHeight_N_sum."\n";
        for($i=0;$i<4;$i++){
            $ImgHeight_N_ratio[$i] = $ImgHeight_N_ratio[$i] / $ImgHeight_N_sum * 10000; // increasing precision
            $ImgHeight_N_ratio[$i] = round($ImgHeight_N_ratio[$i]);
            $ImgHeight_N_ratio[$i] = $ImgHeight_N_ratio[$i]/100;// percentage
            //echo "ImgHeight_N_ratio=".$ImgHeight_N_ratio[$i]."\n";
        }  
        // return
        $this->ImgWidthRatio = $ImgHeight_N_ratio;
        $this->ImgHeight_N = $ImgHeight_N;
        $this->ImgNameList = $ImgNameList;
        $this->GroupIndex = $GroupIndex;
    }// group()
    
}//class ImageRectArray

