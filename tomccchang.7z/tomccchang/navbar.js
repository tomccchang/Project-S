function StartSearchWizard() {
    SearchWizard.style.visibility = "visible";
}

function CloseSearchWizard() {
    SearchWizard.style.visibility = "hidden";
}