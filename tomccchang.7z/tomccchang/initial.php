<?
session_start();
date_default_timezone_set("Asia/Taipei");

include '../conn/conn.php';
$link=@mysqli_connect($servername,$username,$password,$db);
//設定是utf8編碼
mysqli_set_charset($link,utf8);
?>