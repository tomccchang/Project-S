<?php
session_start();
// liste des événements
 $json = array();
 // requête qui récupère les événements
 $requete = "SELECT * FROM Calendar Where (SupplierUID='".$_SESSION['UID']."' Or CustomerUID='".$_SESSION['UID']."')   ORDER BY Start";//.$_SESSION['UID'];
//echo "1232-->".$requete;
 // connexion à la base de données
 //try {
//  $bdd = new PDO('mysql:host=www.synparta.com;dbname=SP_DB', 'SP_DB_WEB', 'VU/Q8286888!');
 include_once "conn/conn_pdo.php";
// } catch(Exception $e) {
// exit('Cant connet to database.');
// }
 // exécution de la requête
 $resultat = $bdd->query($requete) or die(print_r($bdd->errorInfo()));
 
 // envoi du résultat au success
 echo json_encode($resultat->fetchAll(PDO::FETCH_ASSOC));
 
?>
