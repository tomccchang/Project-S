<!-- fetch data -->
<?php

$sql="SELECT * FROM InexCarousel Where Active='Y' AND Kind='nonMobile' Order by Class";
mysqli_query($link,'SET NAMES utf8');
if($result=mysqli_query($link,$sql)){
    $n = 0;
    while ($row=mysqli_fetch_assoc($result)){
        $Num[$n] = $row["Num"];
        $Class[$n] = $row["Class"];
        $Src[$n] = $row["Src"];
        $Alt[$n] = $row["Alt"];
        $Href[$n] = $row["Href"];
        $Active[$n] = $row["Active"];
        $ctl[$n] = "";
        if($Class[$n] == "first-slide"){
            $ctl[$n] ="active";
        }
        $ctl_target[$n] = "";
        if($Href[$n]!="#"){
            $ctl_target[$n] = "target='_blank'";
        }

        $n++;
    }// while
}//if
mysqli_free_result($result);
?>



    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators" style=" z-index: 5;">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
        <li data-target="#myCarousel" data-slide-to="3"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <div class="item active"> 
           <img class="first-slide" src="<? echo "../".$Src[1]; ?>"  alt="First slide">
        </div>

        <div class="item">
          <img class="second-slide" src="<? echo "../".$Src[2]; ?>"  alt="second-slide">
        </div>

        <div class="item">
          <img class="first-slide" src="<? echo "../".$Src[1]; ?>"  alt="First slide">
        </div>

        <div class="item">
          <img class="second-slide" src="<? echo "../".$Src[2]; ?>"  alt="second-slide">
        </div>

      </div>

      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div><!-- /.carousel -->