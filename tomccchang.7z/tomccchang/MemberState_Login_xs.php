<div class="btn-group pull-right RbtnMargin">
  <a type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown">
<img height="20px"  width="20px" class="img-circle"  src="https://graph.facebook.com/<?php echo $_SESSION['FBID']; ?>/picture">
<span class="caret"></span></a>
  <ul class="dropdown-menu" role="menu">
    <li><a href="" id="ablock_i">設定</a></li>
    <li><a href="../register.php" id="ablock_i" <? if($_SESSION['SUPPLIER']==null){ ?> title="請先寫會員資料歐!"<? }?>>會員資料</a></li>
    <li><a href="../logout.php" id="ablock_i">登出</a></li>
  </ul>
</div>

<div class="btn-group pull-right">
  <a type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown">
<span class="glyphicon glyphicon-tasks" style="font-size:1.2em;"></span></a>
  <ul class="dropdown-menu" role="menu">
    <li><a href="TradeMatch.php" id="ablock_i">待回覆訂單</a></li>
    <li><a href="TradeCm.php?H=N" id="ablock_i">未到期訂單</a></li>
    <li><a href="TradeCm.php?H=Y" id="ablock_i">已過期訂單</a></li>
    <li><a href="Ranking.php" id="ablock_i">評價紀錄</a></li>
  </ul>
</div>


<a type="button" class="btn btn-info pull-right" href="../Calendar.php">
  <span class="glyphicon glyphicon-calendar" style="font-size:1.2em;" ></span></a>
</a>


