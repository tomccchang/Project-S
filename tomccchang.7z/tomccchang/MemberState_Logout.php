<a type="button" id="login_btn" href="../loginwithfb/fbconfig.php"  class="btn btn-info pull-right RbtnMargin" style="margin-right: 30px;">
  <span class="glyphicon glyphicon-user"></span> Login
</a>