<? session_start(); ?>


		
	

		<div class="footer-distributed" id="footer" style="position: relative;">

			<div class="footer-left">
				
			<div class="fb-page" data-href="https://www.facebook.com/synparta/" data-width="300" data-height="70" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-show-posts="false"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/synparta/"><a href="https://www.facebook.com/synparta/">星趴達  七海開趴</a></blockquote></div></div>

				<p class="footer-links hw2">
					<a href="https://www.facebook.com/synparta">您的寶貴意見將是我們持續改善與進步的動力，謝謝您！</a>					
				</p>
				<ul class="footer-links " style=" list-style-type: disc;padding-left:20px;"   >		
					<li style="padding-right:6px;padding-left:6px;" id="footer_w"><a href="SPProcess.php">如何成為廠商</a></li>
					<li style="padding-right:6px;padding-left:6px;" id="footer_w"><a href="CSProcess.php">如何成為消費者</a></li>
					<li style="padding-right:6px;padding-left:6px;" id="footer_w"><a href="Synparta.php" >關於星趴達</a></li>											
					<li style="padding-right:6px;padding-left:6px;" id="footer_w"><a href="sc_clause.php" target="_blank">服務條款與免責聲明</a></li>					
				</ul>	



				<p class="footer-company-name">Copyright © 2015 Synparta Inc. All rights reserved</p>



				<div class="footer-icons">

					<a href="https://www.facebook.com/synparta"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
					<a href="#"><i class="fa fa-linkedin"></i></a>
					<a href="#"><i class="fa fa-github"></i></a>

				</div>

			</div>

			<div class="footer-right hw2">

				<p>聯絡我們</p>

				<form action="feedback_db.php" method="post">

					<input type="email" name="email" placeholder="Email"  required/>
					<textarea name="feedback" placeholder="Message" rows="12" required></textarea>
					<button>送出</button>

				</form>

			</div>

		</div>

