<!-- Custom styles for this template -->
<link href="navbar2.css" rel="stylesheet">
<!-- Javascript -->
<script src="navbar.js" type="text/javascript"></script>

<nav class="navbar navbar-custom navbar-fixed-top">

  <div class="row">
    <!-- Brand -->
    <div id="DivBrand" class="hidden-xs col-sm-3 col-md-2 col-lg-2">
      <img id="BrandImg" src="SynpartaBrand.png" alt="Chania">
    </div>
    <div id="DivBrand_xs" class="col-xs-3 hidden-sm hidden-md hidden-lg">
      <button type="button" class="btn btn-info ">
            <span class=""></span>
            <span style="font-size:1.5em;">Synparta</span>
          </button>
    </div>
    <!-- Brand -->

    <!-- dummy spacer -->
    <!--<div class="col-xs-1 hidden-sm col-md-1 col-lg-1"></div>-->

    <!-- NAV Middle -->
    <div id="NavMiddle" class="hidden-xs hidden-sm col-md-3 col-lg-3">
              <a class="btn btn-info" onclick="SecnarioBtn();">
                關於…
              </a>
              <a class="btn btn-info" href="http://www.synparta.com/thomas_Chang/index5.php#ShowZone">
                商品
              </a>
    </div>
    <!-- NAV Middle -->
    <!-- NAV Middle sm  -->
    <div id="NavMiddle_sm" class="col-xs-2 col-sm-1 hidden-md hidden-lg">
          <div class="btn-group">
            <a type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown">
              <span class="glyphicon glyphicon-th" style="font-size:1.2em;"></span>
              <!--<span class="caret"></span> -->
              </a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="#footer_"> 關於… </a></li>
              <li><a href="#showZone"> 商品 </a></li>
            </ul>
          </div>
    </div>
    <!-- NAV Middle sm  -->         

        <!-- NAV Right  -->
        <div id="NavDivRight" class="hidden-xs hidden-sm col-md-1 col-lg-1">
          <a type="button" class="btn btn-info" onclick="StartSearchWizard();">
            <span class="glyphicon glyphicon-search"></span> Search
          </a> 
        </div>

        <div id="NavDivRight_xs" class="hidden-xs col-sm-1 hidden-md hidden-lg">
          <a type="button" class="btn btn-info" style="font-size:1.2em;" onclick="StartSearchWizard();">
            <span class="glyphicon glyphicon-search"></span>
          </a> 
        </div>



        <div id="NavDivRight" class="hidden-xs col-sm-7 col-md-6 col-lg-6">
		      <?php
		      // login or not
		      if ($_SESSION['FBID'] && ($_SESSION['USER_ACTIVE']=='Y')){// log-in
		        include("MemberState_Login.php");

			      // is supplier
		        if($_SESSION['SUPPLIER']=="Y" ){// is supplier
               include("MemberState_Supplier.php");
			      }else{// not supplier
               include("MemberState_NotSupplier.php");
				    }// if($_SESSION['SUPPLIER']=="Y" )
		      }else{// not log-in
			    include("MemberState_Logout.php");
			    //include("MemberState_Supplier.php");		   
		      }// if(login)	  
		     ?>
        </div>


        <div id="NavDivRight_xs" class="col-xs-7 hidden-sm hidden-md hidden-lg">
        <?php
		    // login or not
		      if ($_SESSION['FBID'] && ($_SESSION['USER_ACTIVE']=='Y')){// log-in
		        include("MemberState_Login_xs.php");
            //include("MemberState_Logout.php");
			      // is supplier
		        if($_SESSION['SUPPLIER']=="Y" ){// is supplier
               //include("MemberState_Supplier.php");
			      }else{// not supplier
               //include("MemberState_NotSupplier.php");
				    }// if($_SESSION['SUPPLIER']=="Y" )
		      }else{// not log-in
			    include("MemberState_Logout.php");
		      }// if(login)	  
		   ?>
          <a type="button" class="btn btn-info" style="font-size:1.2em;" onclick="StartSearchWizard();">
            <span class="glyphicon glyphicon-search"></span>
          </a> 

        </div>
        <!-- NAV Right  -->

      </div>
      <!-- row -->
</nav>

<div id="SearchWizard" class="row">
    <?php //include("SearchSelector.php"); 
    include("SearchWizard.php"); 
    ?>
</div>
