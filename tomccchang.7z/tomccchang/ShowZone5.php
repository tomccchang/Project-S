<!--fetch product-->
<?php
$sql=" SELECT * FROM V_IndexSP Where Active='Y' and Kind='selected'";
mysqli_query($link,'SET NAMES utf8');
if($result=mysqli_query($link,$sql)){
    $n = 0;
    while ($row=mysqli_fetch_assoc($result)){
        
        $sd[$n] = $row["UID"];
        $Pic[$n] = $row["Pic"];
        $Kind[$n] = $row["Kind"];
        $ISPR[$n] = $row["ISPR"];
        $Note[$n] = $row["Note"];
        $Start[$n] = $row["Start"];
        $End[$n] = $row["End"];
        $Active[$n] = $row["Active"];
        $Alt[$n] = $row["Alt"];
        $S_NAME[$n] = $row["S_NAME"];
        $ActionCategory[$n] = $row["ActionCategory"];
        $KeyWord[$n] = $row["KeyWord"];
        $CV[$n] = $row["CV"];
        $Service[$n] = $row["Service"];
        $AVG[$n] = $row["AVG"];
        $ImgName[$n]="../SupplierPic/".$sd[$n]."/".$row["Pic"];
        $CV[$n] = (mb_substr( $row["CV"],0,57,"utf-8"));
        $CV[$n] .="...";

        $n++;
    } // end of while ($row=mysqli_fetch_assoc($result)){
}// end of if($result=mysqli_query($link,$sql)){
mysqli_free_result($result);
?>
<!--fetch product-->



<?php
    // configure image array
    include("ImgeRectArray.php");
    $mImgeRectArray_lg = new ImageRectArray();
    $mImgeRectArray_lg->group($ImgName,8,4);

    $mImgeRectArray_md = new ImageRectArray();
    $mImgeRectArray_md->group($ImgName,8,3);

    $mImgeRectArray_sm = new ImageRectArray();
    $mImgeRectArray_sm->group($ImgName,8,2);
 
    $ImgWidthRatio_lg = $mImgeRectArray_lg->ImgWidthRatio;
    //$ImgNameList_lg = $mImgeRectArray_lg->ImgNameList;

    $ImgWidthRatio_md = $mImgeRectArray_md->ImgWidthRatio;
    //$ImgNameList_md = $mImgeRectArray_md->ImgNameList;

    $ImgWidthRatio_sm = $mImgeRectArray_sm->ImgWidthRatio;
    //$ImgNameList_sm = $mImgeRectArray_sm->ImgNameList;
    
?>


  <!--image array-->
  <div class="fluid-container" style="overflow:hidden;" >
  <?php

  // lg 
  for($j=0; $j<4; $j++){
    echo "<div class=\"hidden-xs hidden-sm hidden-md\" style=\"width:$ImgWidthRatio_lg[$j]%; float:left; overflow:hidden;\">";

             for($i=0; $i<2; $i++){
                 //$name = $ImgNameList_lg[$j][$i];
                 //echo $ImgNameList[0][$i];
                 $sd_ = $sd[$mImgeRectArray_lg->GroupIndex[$j][$i]];
                 $AVG_ = $AVG[$mImgeRectArray_lg->GroupIndex[$j][$i]];
                 $path = "../SearchR.php?sd=$sd_&Avg=$AVG_";
                 $name = $ImgName[$mImgeRectArray_lg->GroupIndex[$j][$i]];
                 echo "<div><a href=$path><img  src=$name alt=\"\" style=\"width:100%; height:auto\"></div>";
	           }
    echo "</div>";
  }
  
  // md 
  for($j=0; $j<3; $j++){
    echo "<div class=\"hidden-xs hidden-sm hidden-lg\" style=\"width:$ImgWidthRatio_md[$j]%; float:left;\">";

             for($i=0; $i<4; $i++){
                 //$name = $ImgNameList_md[$j][$i];
                 $name = $ImgName[$mImgeRectArray_md->GroupIndex[$j][$i]];
                 if(empty($name)){break;}
                 $sd_ = $sd[$mImgeRectArray_md->GroupIndex[$j][$i]];
                 $AVG_ = $AVG[$mImgeRectArray_md->GroupIndex[$j][$i]];
                 $path = "../SearchR.php?sd=$sd_&Avg=$AVG_";
                 //echo $ImgNameList[0][$i];
                 echo "<div><a href=$path><img  src=$name alt=\"\" href=\"\" style=\"width:100%; height:auto\"></div>";
	           }
    echo "</div>";
  } 
    
    // sm 
    for($j=0; $j<2; $j++){
    echo "<div class=\"hidden-xs hidden-md hidden-lg\" style=\"width:$ImgWidthRatio_sm[$j]%; float:left;\">";

             for($i=0; $i<4; $i++){
                 //$name = $ImgNameList_sm[$j][$i];
                 $name = $ImgName[$mImgeRectArray_sm->GroupIndex[$j][$i]];
                 if(empty($name)){break;}
                 $sd_ = $sd[$mImgeRectArray_sm->GroupIndex[$j][$i]];
                 $AVG_ = $AVG[$mImgeRectArray_sm->GroupIndex[$j][$i]];
                 $path = "../SearchR.php?sd=$sd_&Avg=$AVG_";
                 //echo $ImgNameList[0][$i];
                 echo "<div><a href=$path><img  src=$name alt=\"\" style=\"width:100%; height:auto\"></div>";
	           }
    echo "</div>";
  } 

    // xs
    echo "<div class=\"hidden-sm hidden-md hidden-lg\" style=\"width:100%;\">";
             for($i=0; $i<8; $i++){
                 $name = $ImgName[$i];
                 if(empty($name)){break;}
                 $sd_ = $sd[$i];
                 $AVG_ = $AVG[$i];
                 $path = "../SearchR.php?sd=$sd_&Avg=$AVG_";
                 //echo $ImgNameList[0][$i];
                 echo "<div><a href=$path><img  src=$name alt=\"\" style=\"width:100%; height:auto\"></div>";
	           }
    echo "</div>";
    
    ?> 
  </div> <!--<div class="row">-->
  <!--image array-->

<!--debug -->

<!--debug -->